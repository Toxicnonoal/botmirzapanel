#!/bin/bash
echo "=== Bot Mirza Panel Installer ==="

read -p "Enter DB username: " DB_USER
read -sp "Enter DB password: " DB_PASS
echo
read -p "Enter your domain (e.g. example.com): " DOMAIN
read -p "Enter Zarinpal Merchant ID: " ZP_MERCHANT

# Update & install dependencies
sudo apt update && sudo apt -y upgrade
sudo apt -y install php php-cli php-curl php-mbstring unzip nginx mariadb-server

# Setup database (simplified)
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS botmirza;"

# Save config
echo "<?php
define('DB_USER', '$DB_USER');
define('DB_PASS', '$DB_PASS');
define('DB_NAME', 'botmirza');
define('ZARINPAL_MERCHANT', '$ZP_MERCHANT');
define('ZARINPAL_CALLBACK', 'http://$DOMAIN/payment/zarinpal_callback.php');
?>" > config.local.php

echo "Installation complete. Configure your web server root to point to this project folder."
