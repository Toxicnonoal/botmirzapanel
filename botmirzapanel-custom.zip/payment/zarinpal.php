<?php
// Zarinpal integration (simplified)
