<?php
// Content manager for admin
